const sensorinfoC = {
    name: 'sensorinfo',
    template: `
    <h2>Sensor informasjon</h2>

    Lekkasje: ----
    
          
    `,
    data: function() {
        return {

        };
    },
}